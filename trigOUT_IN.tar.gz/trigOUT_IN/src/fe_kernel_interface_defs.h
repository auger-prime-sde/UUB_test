
/*this is still not clear if it will be possible to work like that ... */
//#define fe_kernel_interface_shwr_dev0 "/dev/uio0"
//#define fe_kernel_interface_shwr_dev1 "/dev/uio1"
//#define fe_kernel_interface_shwr_dev2 "/dev/uio2"
//#define fe_kernel_interface_shwr_dev3 "/dev/uio3"
//#define fe_kernel_interface_shwr_dev4 "/dev/uio4"
//
//#define fe_kernel_interface_muon_dev0 "/dev/uio5"
//#define fe_kernel_interface_muon_dev1 "/dev/uio6"
//
//#define fe_kernel_interface_registers "/sys/uio.../map" 
