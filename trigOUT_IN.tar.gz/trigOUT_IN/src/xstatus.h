#include<stdint.h>
typedef int XStatus;
typedef uint32_t u32;
